# Nested

jQuery Nested plugin for a gap free, multi column grid layout experience.
<br>Demo: [http://suprb.com/apps/nested/](http://suprb.com/apps/nested/)

#### Changelog

- **1.01**  
Fixed bug when first element was not rendered

- **1.0**  
Initial release

#### Contributor

[Jonas Blomdin](http://github.com/jonasblomdin/)

#### Compare the result

Nested to the left and Grid-A-Licious, Masonry to the right.

!["compare"](https://dl.dropbox.com/u/35476/compare.jpg)

